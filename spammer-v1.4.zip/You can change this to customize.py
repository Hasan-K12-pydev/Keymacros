import tkinter as tk
from tkinter import ttk
import keyboard
import threading
import time
import os

class SpammerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Key Spammer v1.4")
        self.root.geometry("340x380")
        self.root.resizable(False, False)
        
        # Set the window icon in the top-left corner (checking file existence to prevent errors)
        if os.path.exists('icon.ico'):
            self.root.iconbitmap('icon.ico')
        
        self.running = False
        
        # --- UI Elements ---
        title_label = ttk.Label(root, text="Custom Keyboard Macro", font=("Arial", 14, "bold"))
        title_label.pack(pady=10)
        
        # Key Configuration Frame
        key_frame = ttk.LabelFrame(root, text=" Keys to Activate & Map ", padding=10, takefocus=False)
        key_frame.pack(pady=10, fill="x", padx=20)
        
        # Key 1 Setup
        self.var_1 = tk.BooleanVar(value=True)
        f1 = ttk.Frame(key_frame)
        f1.pack(anchor="w", fill="x", pady=2)
        ttk.Checkbutton(f1, text="Key 1:", variable=self.var_1, takefocus=False).pack(side="left")
        self.entry_key1 = ttk.Entry(f1, width=8, takefocus=True)
        self.entry_key1.insert(0, "q")
        self.entry_key1.pack(side="right", padx=5)
        
        # Key 2 Setup
        self.var_2 = tk.BooleanVar(value=True)
        f2 = ttk.Frame(key_frame)
        f2.pack(anchor="w", fill="x", pady=2)
        ttk.Checkbutton(f2, text="Key 2:", variable=self.var_2, takefocus=False).pack(side="left")
        self.entry_key2 = ttk.Entry(f2, width=8, takefocus=True)
        self.entry_key2.insert(0, "f")
        self.entry_key2.pack(side="right", padx=5)
        
        # Key 3 Setup
        self.var_3 = tk.BooleanVar(value=True)
        f3 = ttk.Frame(key_frame)
        f3.pack(anchor="w", fill="x", pady=2)
        ttk.Checkbutton(f3, text="Key 3:", variable=self.var_3, takefocus=False).pack(side="left")
        self.entry_key3 = ttk.Entry(f3, width=8, takefocus=True)
        self.entry_key3.insert(0, "tab")
        self.entry_key3.pack(side="right", padx=5)
        
        # Speed Delay Frame
        speed_frame = ttk.Frame(root, takefocus=False)
        speed_frame.pack(pady=10)
        
        ttk.Label(speed_frame, text="Key Delay (Seconds):", takefocus=False).pack(side="left", padx=5)
        self.speed_entry = ttk.Entry(speed_frame, width=6, takefocus=True)
        self.speed_entry.insert(0, "0.1")
        self.speed_entry.pack(side="left", padx=5)
        
        # Status & Toggle Button
        self.status_label = ttk.Label(root, text="Status: Stopped", foreground="red", font=("Arial", 10, "bold"), takefocus=False)
        self.status_label.pack(pady=5)
        
        self.btn_toggle = ttk.Button(root, text="START (F8)", command=self.toggle_spammer, width=20, takefocus=False)
        self.btn_toggle.pack(pady=10)
        
        self.root.configure(takefocus=False)
        
        self.spammer_thread = threading.Thread(target=self.key_spammer_loop, daemon=True)
        self.spammer_thread.start()
        
        keyboard.add_hotkey('f8', self.toggle_spammer)
        
    def toggle_spammer(self):
        self.running = not self.running
        if self.running:
            self.root.focus_set()  # Shifts focus out of entries so it doesn't spam inside them
            self.status_label.config(text="Status: RUNNING...", foreground="green")
            self.btn_toggle.config(text="STOP (F8)")
        else:
            self.status_label.config(text="Status: Stopped", foreground="red")
            self.btn_toggle.config(text="START (F8)")

    def key_spammer_loop(self):
        while True:
            if self.running:
                try:
                    delay = float(self.speed_entry.get())
                    if delay < 0.01: delay = 0.01
                except ValueError:
                    delay = 0.1
                
                # Fetch dynamically assigned custom keys from entry fields
                key1 = self.entry_key1.get().strip()
                key2 = self.entry_key2.get().strip()
                key3 = self.entry_key3.get().strip()
                
                if self.var_1.get() and key1 and self.running:
                    keyboard.send(key1)
                    time.sleep(delay)
                    
                if self.var_2.get() and key2 and self.running:
                    keyboard.send(key2)
                    time.sleep(delay)
                    
                if self.var_3.get() and key3 and self.running:
                    keyboard.send(key3)
                    time.sleep(delay)
            else:
                time.sleep(0.1)

if __name__ == "__main__":
    root = tk.Tk()
    app = SpammerGUI(root)
    root.mainloop()
