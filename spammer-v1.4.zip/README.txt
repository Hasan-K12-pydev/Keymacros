# Key Spammer v1.3

A lightweight, multi-threaded GUI application built with Python and Tkinter that allows users to create automated keyboard macros with full key-mapping flexibility. 

## Features

- **Custom Key Mapping:** Assign any standard character or special key function (e.g., `q`, `f`, `tab`, `space`, `enter`, `shift`) dynamically via the user interface.
- **Independent Key Toggles:** Activate or deactivate any combination of the three mapped key slots instantly using checkboxes.
- **Adjustable Key Delay:** Set precise macro speed configurations in seconds (supports high-speed actions down to a `0.01` second minimum buffer safety).
- **Global Hotkey Control:** Start and stop the spammer module at any time using the global `F8` shortcut binding, even while minimized or in-game.
- **Form Focus Protection:** Automatically releases active text-field selection upon launch to protect custom configuration values from self-input inflation.

## Prerequisites

Before launching the utility, ensure you have Python 3.x installed along with the required third-party input processing library:

```bash
pip install keyboard
```

> **Note:** Because the underlying `keyboard` dependency hooks into OS-level peripheral triggers, executing this script on Linux operating systems may require root privileges (`sudo`).

## Getting Started

1. **Download or Clone:** Save the script file locally as `main.py`.
2. **Icon Asset (Optional):** Drop a custom interface asset named `icon.ico` directly into the same directory root to personalize the application window.
3. **Execution:** Launch the main interface via your system console terminal:
   ```bash
   python main.py
   ```

## How to Use

1. **Configure Parameters:** Map your target triggers inside the respective **Key 1**, **Key 2**, and **Key 3** input configurations.
2. **Toggle Selections:** Tick or untick checkboxes to control which keys participate in the macro cycle loop sequence.
3. **Define Velocity:** Update the **Key Delay (Seconds)** input field to adjust the specific pacing of macro execution.
4. **Initiate Macro Cycle:** Click the **START (F8)** interface toggle button or press your global `F8` keyboard key to begin execution. Press `F8` again to halt the looping pipeline sequence.

## Project Structure

```text
├── main.py          # Core application logic and Tkinter GUI structure
└── icon.ico         # Optional system window title-bar icon asset
```

## License

This software utility is open-source and free to adapt for personal automation or script optimization workflows.